package ir.fixq.viewer;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.OpenableColumns;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import org.json.JSONObject;

import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;

public class MainActivity extends Activity {

    private static final String HOST = "appassets.androidplatform.net";
    private static final String START = "https://" + HOST + "/assets/www/index.html";
    private static final int PICK = 1001;
    private static final String[] MIME_TYPES = {
            "application/pdf",
            "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
            "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
            "application/vnd.ms-excel",
            "application/msword",
            "text/csv",
            "text/comma-separated-values",
            "text/plain"
    };

    private WebView web;
    private boolean pageReady = false;
    private Uri pendingUri;
    private final Map<String, Uri> served = new HashMap<>();
    private int counter = 0;
    private ValueCallback<Uri[]> chooserCallback;

    @SuppressLint({"SetJavaScriptEnabled", "AddJavascriptInterface"})
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        web = new WebView(this);
        web.setBackgroundColor(0xFFF3F4F7);
        setContentView(web);

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(true);
        s.setSupportZoom(true);
        s.setBuiltInZoomControls(true);
        s.setDisplayZoomControls(false);

        web.addJavascriptInterface(new Bridge(), "FQAndroid");

        web.setWebViewClient(new WebViewClient() {
            @Override
            public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                return intercept(request.getUrl());
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri u = request.getUrl();
                if (HOST.equals(u.getHost())) return false;
                try {
                    Intent i = "tel".equals(u.getScheme()) ? new Intent(Intent.ACTION_DIAL, u) : new Intent(Intent.ACTION_VIEW, u);
                    startActivity(i);
                } catch (ActivityNotFoundException ignored) { }
                return true;
            }
        });

        web.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback, FileChooserParams params) {
                if (chooserCallback != null) chooserCallback.onReceiveValue(null);
                chooserCallback = callback;
                Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                i.addCategory(Intent.CATEGORY_OPENABLE);
                i.setType("*/*");
                i.putExtra(Intent.EXTRA_MIME_TYPES, MIME_TYPES);
                try {
                    startActivityForResult(i, PICK);
                } catch (ActivityNotFoundException e) {
                    Intent g = new Intent(Intent.ACTION_GET_CONTENT);
                    g.addCategory(Intent.CATEGORY_OPENABLE);
                    g.setType("*/*");
                    try {
                        startActivityForResult(g, PICK);
                    } catch (ActivityNotFoundException e2) {
                        chooserCallback.onReceiveValue(null);
                        chooserCallback = null;
                    }
                }
                return true;
            }
        });

        handleIntent(getIntent());
        if (savedInstanceState != null) web.restoreState(savedInstanceState);
        else web.loadUrl(START);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != PICK || chooserCallback == null) return;
        Uri uri = (resultCode == RESULT_OK && data != null) ? data.getData() : null;
        chooserCallback.onReceiveValue(uri != null ? new Uri[]{uri} : null);
        chooserCallback = null;
    }

    @Override
    @SuppressWarnings("deprecation")
    public void onBackPressed() {
        if (web != null && web.canGoBack()) web.goBack();
        else super.onBackPressed();
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        handleIntent(intent);
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        if (web != null) web.saveState(outState);
    }

    @Override
    protected void onDestroy() {
        if (web != null) web.destroy();
        super.onDestroy();
    }

    /* Serve app files from assets/ and opened files from content URIs */
    private WebResourceResponse intercept(Uri url) {
        if (url == null || !HOST.equals(url.getHost())) return null;
        String path = url.getPath();
        if (path == null) return null;
        try {
            if (path.startsWith("/assets/")) {
                String asset = path.substring("/assets/".length());
                InputStream in = getAssets().open(asset);
                return response(mimeFor(asset), in, 200, "OK");
            }
            if (path.startsWith("/opened/")) {
                Uri uri = served.get(path.substring("/opened/".length()));
                if (uri == null) return response("text/plain", null, 404, "Not Found");
                String type = getContentResolver().getType(uri);
                InputStream in = getContentResolver().openInputStream(uri);
                return response(type == null ? "application/octet-stream" : type, in, 200, "OK");
            }
        } catch (Exception e) {
            return response("text/plain", null, 404, "Not Found");
        }
        return response("text/plain", null, 404, "Not Found");
    }

    private WebResourceResponse response(String mime, InputStream in, int code, String reason) {
        Map<String, String> headers = new HashMap<>();
        headers.put("Access-Control-Allow-Origin", "*");
        headers.put("Cache-Control", "no-cache");
        String enc = mime.startsWith("text/") || mime.contains("javascript") || mime.contains("json") ? "utf-8" : null;
        return new WebResourceResponse(mime, enc, code, reason, headers, in);
    }

    private static String mimeFor(String name) {
        String n = name.toLowerCase();
        if (n.endsWith(".html")) return "text/html";
        if (n.endsWith(".js") || n.endsWith(".mjs")) return "text/javascript";
        if (n.endsWith(".css")) return "text/css";
        if (n.endsWith(".json") || n.endsWith(".webmanifest")) return "application/json";
        if (n.endsWith(".wasm")) return "application/wasm";
        if (n.endsWith(".png")) return "image/png";
        if (n.endsWith(".svg")) return "image/svg+xml";
        return "application/octet-stream";
    }

    @SuppressWarnings("deprecation")
    private void handleIntent(Intent intent) {
        if (intent == null) return;
        Uri uri = null;
        String action = intent.getAction();
        if (Intent.ACTION_VIEW.equals(action)) {
            uri = intent.getData();
        } else if (Intent.ACTION_SEND.equals(action)) {
            if (Build.VERSION.SDK_INT >= 33) uri = intent.getParcelableExtra(Intent.EXTRA_STREAM, Uri.class);
            else uri = intent.getParcelableExtra(Intent.EXTRA_STREAM);
        }
        if (uri == null) return;
        pendingUri = uri;
        if (pageReady) deliver();
    }

    private void deliver() {
        Uri uri = pendingUri;
        pendingUri = null;
        if (uri == null || web == null) return;
        String key = String.valueOf(++counter);
        served.put(key, uri);
        String type = getContentResolver().getType(uri);
        String js = "window.fqOpenFromUrl && window.fqOpenFromUrl(" +
                JSONObject.quote("/opened/" + key) + "," +
                JSONObject.quote(displayName(uri)) + "," +
                JSONObject.quote(type == null ? "" : type) + ")";
        web.evaluateJavascript(js, null);
    }

    private String displayName(Uri uri) {
        String name = null;
        if ("content".equals(uri.getScheme())) {
            Cursor c = null;
            try {
                c = getContentResolver().query(uri, new String[]{OpenableColumns.DISPLAY_NAME}, null, null, null);
                if (c != null && c.moveToFirst()) name = c.getString(0);
            } catch (Exception ignored) {
            } finally {
                if (c != null) c.close();
            }
        }
        if (name == null) name = uri.getLastPathSegment();
        if (name == null) name = "file";
        int slash = name.lastIndexOf('/');
        if (slash >= 0) name = name.substring(slash + 1);
        if (!name.contains(".")) {
            String t = getContentResolver().getType(uri);
            if ("application/pdf".equals(t)) name += ".pdf";
            else if (t != null && t.contains("spreadsheetml")) name += ".xlsx";
            else if (t != null && t.contains("wordprocessingml")) name += ".docx";
            else if (t != null && t.contains("csv")) name += ".csv";
            else if ("text/plain".equals(t)) name += ".txt";
        }
        return name;
    }

    private class Bridge {
        @JavascriptInterface
        public void ready() {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    pageReady = true;
                    if (pendingUri != null) deliver();
                }
            });
        }
    }
}
